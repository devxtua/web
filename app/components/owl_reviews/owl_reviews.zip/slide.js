"use strict";
var Slide = (function () {
    function Slide(htmlContent, imgUrl) {
    }
    return Slide;
}());
exports.Slide = Slide;
//# sourceMappingURL=slide.js.map