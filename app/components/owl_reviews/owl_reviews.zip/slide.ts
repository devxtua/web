export class Slide {
	constructor (
		htmlContent: string,
		imgUrl: string
	){

	}
}